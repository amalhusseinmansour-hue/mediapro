<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class AnalyticsController extends Controller
{
    /**
     * GET /api/analytics/usage
     * عرض استخدام المستخدم الحالي مقابل حدود الباقة
     */
    public function getUsage(Request $request): JsonResponse
    {
        $user = $request->user();

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 401);
        }

        $subscription = $user->subscription;

        if (!$subscription) {
            return response()->json([
                'success' => false,
                'message' => 'No active subscription found',
            ], 404);
        }

        // إعادة تعيين العدادات إذا لزم الأمر
        $subscription->resetCountersIfNeeded();

        $maxPosts = $subscription->custom_max_posts ?? $subscription->max_posts ?? 999999;
        $maxAIRequests = $subscription->custom_max_ai_requests ?? 999999;

        return response()->json([
            'success' => true,
            'usage' => [
                // المنشورات
                'posts' => [
                    'current' => $subscription->current_posts_count,
                    'limit' => $maxPosts,
                    'is_unlimited' => $maxPosts >= 999999,
                    'percentage' => $subscription->getPostsUsagePercentage(),
                    'remaining' => $subscription->getRemainingPosts(),
                    'reset_date' => $subscription->posts_reset_date?->toIso8601String(),
                ],

                // الذكاء الاصطناعي
                'ai_requests' => [
                    'current' => $subscription->current_ai_requests_count,
                    'limit' => $maxAIRequests,
                    'is_unlimited' => $maxAIRequests >= 999999,
                    'is_available' => $subscription->ai_features,
                    'percentage' => $subscription->getAIUsagePercentage(),
                    'remaining' => $subscription->getRemainingAIRequests(),
                    'reset_date' => $subscription->ai_requests_reset_date?->toIso8601String(),
                ],

                // الحسابات المربوطة
                'connected_accounts' => [
                    'current' => $user->connected_accounts_count ?? 0,
                    'limit' => $subscription->max_accounts ?? 999999,
                    'percentage' => $subscription->max_accounts > 0
                        ? round((($user->connected_accounts_count ?? 0) / $subscription->max_accounts) * 100, 2)
                        : 0,
                    'remaining' => max(0, ($subscription->max_accounts ?? 999999) - ($user->connected_accounts_count ?? 0)),
                ],
            ],
        ]);
    }

    /**
     * GET /api/analytics/overview
     * نظرة عامة على الأداء
     */
    public function getOverview(Request $request): JsonResponse
    {
        $user = $request->user();

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 401);
        }

        // جلب بيانات حقيقية من قاعدة البيانات
        $totalFollowers = DB::table('connected_accounts')
            ->where('user_id', $user->id)
            ->sum('followers_count') ?? 0;

        $totalPosts = DB::table('posts')
            ->where('user_id', $user->id)
            ->count();

        $totalEngagement = DB::table('posts')
            ->where('user_id', $user->id)
            ->sum('engagement_count') ?? 0;

        $totalReach = DB::table('posts')
            ->where('user_id', $user->id)
            ->sum('reach_count') ?? 0;

        // حساب معدل التفاعل
        $engagementRate = $totalReach > 0
            ? round(($totalEngagement / $totalReach) * 100, 2)
            : 0;

        // معدل النمو (مقارنة بالشهر السابق)
        $previousMonthFollowers = DB::table('connected_accounts')
            ->where('user_id', $user->id)
            ->sum('previous_month_followers') ?? 0;

        $followersGrowth = $previousMonthFollowers > 0
            ? round((($totalFollowers - $previousMonthFollowers) / $previousMonthFollowers) * 100, 2)
            : 0;

        return response()->json([
            'success' => true,
            'overview' => [
                'total_followers' => $totalFollowers,
                'total_posts' => $totalPosts,
                'total_engagement' => $totalEngagement,
                'total_reach' => $totalReach,
                'engagement_rate' => $engagementRate,
                'followers_growth' => $followersGrowth,
                'followers_growth_percentage' => $followersGrowth > 0 ? "+{$followersGrowth}%" : "{$followersGrowth}%",
            ],
        ]);
    }

    /**
     * GET /api/analytics/posts
     * تحليلات المنشورات
     */
    public function getPostsAnalytics(Request $request): JsonResponse
    {
        $user = $request->user();

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 401);
        }

        $period = $request->get('period', 'week'); // day, week, month, year

        $startDate = match ($period) {
            'day' => now()->subDay(),
            'week' => now()->subWeek(),
            'month' => now()->subMonth(),
            'year' => now()->subYear(),
            default => now()->subWeek(),
        };

        // أفضل المنشورات
        $topPosts = DB::table('posts')
            ->where('user_id', $user->id)
            ->where('created_at', '>=', $startDate)
            ->orderBy('engagement_count', 'desc')
            ->limit(5)
            ->select([
                'id',
                'content',
                'platform',
                'engagement_count',
                'reach_count',
                'shares_count',
                'created_at',
            ])
            ->get();

        // أداء حسب المنصة
        $platformPerformance = DB::table('posts')
            ->where('user_id', $user->id)
            ->where('created_at', '>=', $startDate)
            ->select('platform')
            ->selectRaw('COUNT(*) as posts_count')
            ->selectRaw('SUM(engagement_count) as total_engagement')
            ->selectRaw('SUM(reach_count) as total_reach')
            ->selectRaw('ROUND(AVG(engagement_count), 2) as avg_engagement')
            ->groupBy('platform')
            ->get();

        return response()->json([
            'success' => true,
            'analytics' => [
                'period' => $period,
                'start_date' => $startDate->toIso8601String(),
                'end_date' => now()->toIso8601String(),
                'top_posts' => $topPosts,
                'platform_performance' => $platformPerformance,
            ],
        ]);
    }

    /**
     * GET /api/analytics/platforms
     * تحليلات المنصات
     */
    public function getPlatformsAnalytics(Request $request): JsonResponse
    {
        $user = $request->user();

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 401);
        }

        // إحصائيات كل منصة
        $platformsStats = DB::table('connected_accounts')
            ->where('user_id', $user->id)
            ->select([
                'platform',
                'followers_count',
                'is_connected',
                'last_sync_at',
            ])
            ->get();

        // أداء المنشورات حسب المنصة
        $platformsPosts = DB::table('posts')
            ->where('user_id', $user->id)
            ->select('platform')
            ->selectRaw('COUNT(*) as total_posts')
            ->selectRaw('SUM(engagement_count) as total_engagement')
            ->selectRaw('SUM(reach_count) as total_reach')
            ->selectRaw('ROUND(SUM(engagement_count) / NULLIF(SUM(reach_count), 0) * 100, 2) as engagement_rate')
            ->groupBy('platform')
            ->get();

        // دمج البيانات
        $platformsData = [];

        foreach ($platformsStats as $stat) {
            $postData = $platformsPosts->firstWhere('platform', $stat->platform);

            $platformsData[] = [
                'platform' => $stat->platform,
                'followers' => $stat->followers_count ?? 0,
                'is_connected' => $stat->is_connected ?? false,
                'last_sync' => $stat->last_sync_at,
                'total_posts' => $postData->total_posts ?? 0,
                'total_engagement' => $postData->total_engagement ?? 0,
                'total_reach' => $postData->total_reach ?? 0,
                'engagement_rate' => $postData->engagement_rate ?? 0,
            ];
        }

        return response()->json([
            'success' => true,
            'platforms' => $platformsData,
        ]);
    }

    /**
     * GET /api/analytics/check-limit/{type}
     * التحقق من الحد قبل القيام بعملية
     */
    public function checkLimit(Request $request, string $type): JsonResponse
    {
        $user = $request->user();

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 401);
        }

        $subscription = $user->subscription;

        if (!$subscription) {
            return response()->json([
                'success' => false,
                'message' => 'No active subscription',
                'can_proceed' => false,
            ], 403);
        }

        $canProceed = false;
        $message = '';
        $current = 0;
        $limit = 0;
        $remaining = 0;

        switch ($type) {
            case 'post':
                $canProceed = !$subscription->hasReachedPostsLimit();
                $current = $subscription->current_posts_count;
                $limit = $subscription->custom_max_posts ?? $subscription->max_posts ?? 999999;
                $remaining = $subscription->getRemainingPosts();
                $message = $canProceed
                    ? 'يمكنك إنشاء منشور جديد'
                    : 'لقد وصلت للحد الأقصى من المنشورات لهذا الشهر';
                break;

            case 'ai':
                $canProceed = !$subscription->hasReachedAILimit();
                $current = $subscription->current_ai_requests_count;
                $limit = $subscription->custom_max_ai_requests ?? 999999;
                $remaining = $subscription->getRemainingAIRequests();
                $message = $canProceed
                    ? 'يمكنك استخدام الذكاء الاصطناعي'
                    : 'لقد وصلت للحد الأقصى من طلبات AI لهذا الشهر';
                break;

            case 'account':
                $currentAccounts = $user->connected_accounts_count ?? 0;
                $maxAccounts = $subscription->max_accounts ?? 999999;
                $canProceed = $currentAccounts < $maxAccounts;
                $current = $currentAccounts;
                $limit = $maxAccounts;
                $remaining = max(0, $maxAccounts - $currentAccounts);
                $message = $canProceed
                    ? 'يمكنك ربط حساب جديد'
                    : 'لقد وصلت للحد الأقصى من الحسابات';
                break;

            default:
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid limit type',
                ], 400);
        }

        return response()->json([
            'success' => true,
            'can_proceed' => $canProceed,
            'message' => $message,
            'usage' => [
                'current' => $current,
                'limit' => $limit,
                'remaining' => $remaining,
                'percentage' => $limit > 0 ? round(($current / $limit) * 100, 2) : 0,
            ],
        ]);
    }
}

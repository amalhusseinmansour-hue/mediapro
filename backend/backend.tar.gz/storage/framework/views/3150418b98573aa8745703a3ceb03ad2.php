<div
    <?php echo e($attributes->class(['fi-fo-field-wrp-helper-text break-words text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\HP\social_media_manager\backend\vendor\filament\forms\resources\views/components/field-wrapper/helper-text.blade.php ENDPATH**/ ?>
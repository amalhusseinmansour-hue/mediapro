<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.api-key-resource.pages.create-api-key' => 'App\\Filament\\Resources\\ApiKeyResource\\Pages\\CreateApiKey',
    'app.filament.resources.api-key-resource.pages.edit-api-key' => 'App\\Filament\\Resources\\ApiKeyResource\\Pages\\EditApiKey',
    'app.filament.resources.api-key-resource.pages.list-api-keys' => 'App\\Filament\\Resources\\ApiKeyResource\\Pages\\ListApiKeys',
    'app.filament.resources.api-log-resource.pages.list-api-logs' => 'App\\Filament\\Resources\\ApiLogResource\\Pages\\ListApiLogs',
    'app.filament.resources.api-log-resource.pages.view-api-log' => 'App\\Filament\\Resources\\ApiLogResource\\Pages\\ViewApiLog',
    'app.filament.resources.earning-resource.pages.list-earnings' => 'App\\Filament\\Resources\\EarningResource\\Pages\\ListEarnings',
    'app.filament.resources.earning-resource.pages.view-earning' => 'App\\Filament\\Resources\\EarningResource\\Pages\\ViewEarning',
    'app.filament.resources.language-resource.pages.create-language' => 'App\\Filament\\Resources\\LanguageResource\\Pages\\CreateLanguage',
    'app.filament.resources.language-resource.pages.edit-language' => 'App\\Filament\\Resources\\LanguageResource\\Pages\\EditLanguage',
    'app.filament.resources.language-resource.pages.list-languages' => 'App\\Filament\\Resources\\LanguageResource\\Pages\\ListLanguages',
    'app.filament.resources.notification-resource.pages.create-notification' => 'App\\Filament\\Resources\\NotificationResource\\Pages\\CreateNotification',
    'app.filament.resources.notification-resource.pages.edit-notification' => 'App\\Filament\\Resources\\NotificationResource\\Pages\\EditNotification',
    'app.filament.resources.notification-resource.pages.list-notifications' => 'App\\Filament\\Resources\\NotificationResource\\Pages\\ListNotifications',
    'app.filament.resources.page-resource.pages.create-page' => 'App\\Filament\\Resources\\PageResource\\Pages\\CreatePage',
    'app.filament.resources.page-resource.pages.edit-page' => 'App\\Filament\\Resources\\PageResource\\Pages\\EditPage',
    'app.filament.resources.page-resource.pages.list-pages' => 'App\\Filament\\Resources\\PageResource\\Pages\\ListPages',
    'app.filament.resources.payment-resource.pages.list-payments' => 'App\\Filament\\Resources\\PaymentResource\\Pages\\ListPayments',
    'app.filament.resources.payment-resource.pages.view-payment' => 'App\\Filament\\Resources\\PaymentResource\\Pages\\ViewPayment',
    'app.filament.resources.setting-resource.pages.create-setting' => 'App\\Filament\\Resources\\SettingResource\\Pages\\CreateSetting',
    'app.filament.resources.setting-resource.pages.edit-setting' => 'App\\Filament\\Resources\\SettingResource\\Pages\\EditSetting',
    'app.filament.resources.setting-resource.pages.list-settings' => 'App\\Filament\\Resources\\SettingResource\\Pages\\ListSettings',
    'app.filament.resources.subscription-plan-resource.pages.create-subscription-plan' => 'App\\Filament\\Resources\\SubscriptionPlanResource\\Pages\\CreateSubscriptionPlan',
    'app.filament.resources.subscription-plan-resource.pages.edit-subscription-plan' => 'App\\Filament\\Resources\\SubscriptionPlanResource\\Pages\\EditSubscriptionPlan',
    'app.filament.resources.subscription-plan-resource.pages.list-subscription-plans' => 'App\\Filament\\Resources\\SubscriptionPlanResource\\Pages\\ListSubscriptionPlans',
    'app.filament.resources.subscription-resource.pages.create-subscription' => 'App\\Filament\\Resources\\SubscriptionResource\\Pages\\CreateSubscription',
    'app.filament.resources.subscription-resource.pages.edit-subscription' => 'App\\Filament\\Resources\\SubscriptionResource\\Pages\\EditSubscription',
    'app.filament.resources.subscription-resource.pages.list-subscriptions' => 'App\\Filament\\Resources\\SubscriptionResource\\Pages\\ListSubscriptions',
    'app.filament.resources.subscription-resource.pages.view-subscription' => 'App\\Filament\\Resources\\SubscriptionResource\\Pages\\ViewSubscription',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'app.filament.pages.api-documentation' => 'App\\Filament\\Pages\\ApiDocumentation',
    'app.filament.pages.app-settings' => 'App\\Filament\\Pages\\AppSettings',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'app.filament.widgets.api-stats-widget' => 'App\\Filament\\Widgets\\ApiStatsWidget',
    'app.filament.widgets.latest-subscriptions' => 'App\\Filament\\Widgets\\LatestSubscriptions',
    'app.filament.widgets.stats-overview' => 'App\\Filament\\Widgets\\StatsOverview',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Pages\\ApiDocumentation.php' => 'App\\Filament\\Pages\\ApiDocumentation',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Pages\\AppSettings.php' => 'App\\Filament\\Pages\\AppSettings',
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Resources\\ApiKeyResource.php' => 'App\\Filament\\Resources\\ApiKeyResource',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Resources\\ApiLogResource.php' => 'App\\Filament\\Resources\\ApiLogResource',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Resources\\EarningResource.php' => 'App\\Filament\\Resources\\EarningResource',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Resources\\LanguageResource.php' => 'App\\Filament\\Resources\\LanguageResource',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Resources\\NotificationResource.php' => 'App\\Filament\\Resources\\NotificationResource',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Resources\\PageResource.php' => 'App\\Filament\\Resources\\PageResource',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Resources\\PaymentResource.php' => 'App\\Filament\\Resources\\PaymentResource',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Resources\\SettingResource.php' => 'App\\Filament\\Resources\\SettingResource',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Resources\\SubscriptionPlanResource.php' => 'App\\Filament\\Resources\\SubscriptionPlanResource',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Resources\\SubscriptionResource.php' => 'App\\Filament\\Resources\\SubscriptionResource',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Widgets\\ApiStatsWidget.php' => 'App\\Filament\\Widgets\\ApiStatsWidget',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Widgets\\LatestSubscriptions.php' => 'App\\Filament\\Widgets\\LatestSubscriptions',
    'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament\\Widgets\\StatsOverview.php' => 'App\\Filament\\Widgets\\StatsOverview',
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'App\\Filament\\Widgets\\StatsOverview',
    2 => 'App\\Filament\\Widgets\\LatestSubscriptions',
    3 => 'App\\Filament\\Widgets\\ApiStatsWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\Users\\HP\\social_media_manager\\backend\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);
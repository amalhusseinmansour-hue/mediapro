<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\SubscriptionController;
use App\Http\Controllers\Api\WalletController;
use App\Http\Controllers\Api\WebsiteRequestController;
use App\Http\Controllers\Api\SponsoredAdRequestController;
use App\Http\Controllers\Api\SupportTicketController;

// Public routes
Route::post('/auth/register', [AuthController::class, 'register']);
Route::post('/auth/send-otp', [AuthController::class, 'sendOTP']);
Route::post('/auth/login', [AuthController::class, 'login']);

// Health check
Route::get('/health', function () {
    return response()->json(['status' => 'ok', 'timestamp' => now()]);
});

// Subscription Plans (Public - anyone can view available plans)
Route::get('/subscription-plans', function () {
    // الخطط مخزنة في جدول subscriptions مع is_plan = true
    $plans = \App\Models\Subscription::where('is_plan', true)
        ->where('is_active', true)
        ->orderBy('price', 'asc')
        ->get();

    // إذا لم توجد خطط، نقوم بإنشائها
    if ($plans->isEmpty()) {
        \Artisan::call('db:seed', ['--class' => 'SubscriptionPlansSeeder']);
        $plans = \App\Models\Subscription::where('is_plan', true)
            ->where('is_active', true)
            ->orderBy('price', 'asc')
            ->get();
    }

    return response()->json([
        'success' => true,
        'plans' => $plans
    ]);
});

// Website Requests (Public - anyone can submit)
Route::post('/website-requests', [WebsiteRequestController::class, 'store']);

// Sponsored Ad Requests (Public - anyone can submit)
Route::post('/sponsored-ad-requests', [SponsoredAdRequestController::class, 'store']);

// Support Tickets (Public - anyone can submit)
Route::post('/support-tickets', [SupportTicketController::class, 'store']);

// Protected routes
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/auth/logout', [AuthController::class, 'logout']);
    Route::get('/auth/user', [AuthController::class, 'user']);

    Route::apiResource('users', UserController::class);
    Route::post('/subscriptions', [SubscriptionController::class, 'store']);
    Route::get('/subscriptions/{userId}', [SubscriptionController::class, 'show']);

    // Wallet routes
    Route::prefix('wallets')->group(function () {
        // User wallet endpoints
        Route::get('/{userId}', [WalletController::class, 'show']);
        Route::get('/{userId}/transactions', [WalletController::class, 'transactions']);
        Route::post('/{userId}/debit', [WalletController::class, 'debit']);

        // Admin endpoints
        Route::get('/', [WalletController::class, 'index']); // List all wallets
        Route::get('/statistics/all', [WalletController::class, 'statistics']); // Get statistics
        Route::post('/{userId}/credit', [WalletController::class, 'credit']); // Credit wallet
        Route::post('/{userId}/toggle-status', [WalletController::class, 'toggleStatus']); // Toggle status
    });

    // Website Requests Management (Admin only)
    Route::prefix('website-requests')->group(function () {
        Route::get('/', [WebsiteRequestController::class, 'index']); // List all requests
        Route::get('/statistics', [WebsiteRequestController::class, 'statistics']); // Get statistics
        Route::get('/{id}', [WebsiteRequestController::class, 'show']); // View specific request
        Route::put('/{id}', [WebsiteRequestController::class, 'update']); // Update request (status, notes)
        Route::delete('/{id}', [WebsiteRequestController::class, 'destroy']); // Delete request
    });

    // Sponsored Ad Requests Management (Admin only)
    Route::prefix('sponsored-ad-requests')->group(function () {
        Route::get('/', [SponsoredAdRequestController::class, 'index']); // List all requests
        Route::get('/statistics', [SponsoredAdRequestController::class, 'statistics']); // Get statistics
        Route::get('/{id}', [SponsoredAdRequestController::class, 'show']); // View specific request
        Route::put('/{id}', [SponsoredAdRequestController::class, 'update']); // Update request (status, notes)
        Route::delete('/{id}', [SponsoredAdRequestController::class, 'destroy']); // Delete request
    });

    // Support Tickets Management (Admin only)
    Route::prefix('support-tickets')->group(function () {
        Route::get('/', [SupportTicketController::class, 'index']); // List all tickets
        Route::get('/statistics', [SupportTicketController::class, 'statistics']); // Get statistics
        Route::get('/{id}', [SupportTicketController::class, 'show']); // View specific ticket
        Route::put('/{id}', [SupportTicketController::class, 'update']); // Update ticket (status, priority, notes, assign)
        Route::delete('/{id}', [SupportTicketController::class, 'destroy']); // Delete ticket
    });
});

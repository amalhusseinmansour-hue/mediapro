<?php
echo "Hello from PHP!";
echo "<br>PHP Version: " . phpversion();

<?php
namespace App\Filament\Resources\PaymentResource\Pages;
use App\Filament\Resources\PaymentResource;
use Filament\Resources\Pages\ViewRecord;
class ViewPayment extends ViewRecord { protected static string $resource = PaymentResource::class; }

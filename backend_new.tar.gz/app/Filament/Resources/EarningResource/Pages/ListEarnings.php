<?php
namespace App\Filament\Resources\EarningResource\Pages;
use App\Filament\Resources\EarningResource;
use Filament\Resources\Pages\ListRecords;
class ListEarnings extends ListRecords { protected static string $resource = EarningResource::class; }
